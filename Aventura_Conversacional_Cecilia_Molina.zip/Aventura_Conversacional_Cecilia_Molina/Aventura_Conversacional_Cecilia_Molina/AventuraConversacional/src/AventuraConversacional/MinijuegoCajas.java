package AventuraConversacional;
import java.util.Scanner;

public class MinijuegoCajas {
    public void jugar(Jugador jugador) {
        Scanner scanner = new Scanner(System.in);
        int cajaCorrecta = (int) (Math.random() * 3) + 1; 

        System.out.println("\nHay tres cajas frente a ti. Solo una tiene algo útil.");
        System.out.println("Elige una caja (1, 2 o 3): ");
        int eleccion = scanner.nextInt();

        if (eleccion == cajaCorrecta) {
            System.out.println("¡Felicidades! Has encntrado un botiquín de primeros auxilios. Ganas 10 puntos de salud.");
            jugador.aumentarSalud(10);
        } else {
            System.out.println("Oh no... la caja está vacía. Pierdes 5 puntos de salud.");
            jugador.reducirSalud(5);
        }

        System.out.println("Salud actual: " + jugador.getSalud());
    }
}
